export { default } from "./InchDex";
